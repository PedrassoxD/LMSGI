<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Cargar Productos</title>
</head>
<body>
	
	<form action="cargaPedroPerez2.php" method="post">
		
		Elija el archivo que contenga los datos de la tabla productos.
		<input type="file" name="fichero" placeholder="Elegir...">
		<br>
		<br>
		<input type="submit" name="Acceder" placeholder="Cargar">

	</form>

	<br>
	<br>
	
	<a href="indexPedroPerez.php"><h1>Página Principal</h1></a>

</body>
</html>