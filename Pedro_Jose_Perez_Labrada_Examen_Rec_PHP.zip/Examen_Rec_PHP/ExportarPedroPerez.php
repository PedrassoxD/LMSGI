<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Cargar Productos</title>
</head>
<body>
	
	<form action="ExportarPedroPerez2.php" method="post">
		
		CODIGO del departamento del que quiere exportar los datos de sus empleados.
		<input type="text" name="departamento" placeholder="Codigo">
		<br>
		<br>
		<input type="submit" name="Acceder" placeholder="Cargar">

	</form>

	<br>
	<br>
	
	<a href="indexPedroPerez.php"><h1>Página Principal</h1></a>

</body>
</html>