<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Exportar datos a fichero</title>
</head>
<body>

	<br>
	<p>Datos exportados: </p>

	<?php
			
		$link = mysqli_connect('localhost', 'root', 'root');

		$fichero = "CopiaSeguridadPedroPerez.txt";

		$cont = 0;

		$departamento = $_POST['departamento'];

		if($link){

			mysqli_select_db($link, 'PedroPerezEmpresa');

			$query = "SELECT * FROM Empleados WHERE CodDep = \"$departamento\"";

			$result = mysqli_query($link, $query);

			while($extract = mysqli_fetch_array($result)){

				if(file_put_contents($fichero, $extract[0] . "-" . $extract[1] . "-" . $extract[2] . "-" . $extract[3] . "-" . $extract[4] . "-" . $extract[5] . "\n", FILE_APPEND)){
					echo ++$cont . "   " . "Bien. <br>";
				}else{
					echo "ERROR: Imposible exportar los datos." . "<br>";
				}

			}

			echo "<br>";
			echo "<br>";
			echo "Mire la carpeta de su proyecto para ver si esta el fichero con los datos.";


			mysqli_close($link);

		}else{
			echo "ERROR: Imposible establecer la conexión con la base de datos.";
		}

	?>
	
	<br>
	<br>

	<a href="indexPedroPerez.php"><h3>Página Principal</h3></a>

</body>
</html>