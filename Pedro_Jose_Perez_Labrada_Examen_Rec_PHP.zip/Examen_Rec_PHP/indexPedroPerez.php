<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Index</title>
</head>
<body>

	<h1>ENLACES</h1> <br>
	<a href="AltaPedroPerez.php">Alta Empleados.</a> <br>
	<a href="cargaPedroPerez.php">Carga Departamentos.</a> <br>
	<a href="ExportarPedroPerez.php">Exportar datos.</a> <br>

	<?php

		$link = mysqli_connect("localhost", 'root', 'root');

		if($link){

			$create = "CREATE DATABASE IF NOT EXISTS PedroPerezEmpresa";

			if(mysqli_query($link,$create)){
				echo "Base de datos creada" . "<br>";
			}else{
				echo "No se ha podido crear la base de datos, ya existe o hay algún error en la creación.";
			}

			mysqli_select_db($link,'PedroPerezEmpresa');

			$createTable3 = "CREATE TABLE IF NOT EXISTS Departamentos(CodDep VARCHAR(20) PRIMARY KEY, nombre VARCHAR(150), num_emp VARCHAR(20))";

			if(mysqli_query($link, $createTable3)){
				echo "Tabla creada." . "<br>";
			}else{
				echo "La tabla no se ha podido crear.";
			}


			$createTable = "CREATE TABLE IF NOT EXISTS Empleados(CodEmp VARCHAR(20) PRIMARY KEY, dni VARCHAR(20), nombre VARCHAR(20), apellidos VARCHAR(20), edad VARCHAR(20), CodDep VARCHAR(20), FOREIGN KEY (CodDep) REFERENCES Departamentos(CodDep) ON DELETE CASCADE)";

			if($result = mysqli_query($link, $createTable)){
				echo "Tabla creada." . "<br>";
			}else{
				echo "La tabla no se ha podido crear.";
			}


			$insert = "INSERT INTO Departamentos VALUES('1', 'Informatica', '1')";

			if(mysqli_query($link,$insert)){
				echo "Departamento insertado en la tabla";
			}else{
				echo "ERROR: Imposible insertar" . $link->error;
			}


			echo "<br>";
			echo "<br>";


			$insert2 = "INSERT INTO Departamentos VALUES('2', 'Matematicas', '1')";

			if(mysqli_query($link,$insert2)){
				echo "Departamento insertado en la tabla";
			}else{
				echo "ERROR: Imposible insertar";
			}


			echo "<br>";
			echo "<br>";


			$insert3 = "INSERT INTO Departamentos VALUES('3', 'Ingles', '1')";

			if(mysqli_query($link,$insert3)){
				echo "Departamento insertado en la tabla";
			}else{
				echo "ERROR: Imposible insertar";
			}


			echo "<br>";
			echo "<br>";


			$insert4 = "INSERT INTO Empleados VALUES('1', '12345678A', 'Pedro', 'Perez', '18', '1')";

			if(mysqli_query($link,$insert4)){
				echo "Empleado insertado en la tabla";
			}else{
				echo "ERROR: Imposible insertar";
			}


			echo "<br>";
			echo "<br>";


			$insert5 = "INSERT INTO Empleados VALUES('2', '57486214B', 'Ramon', 'Garcia', '22', '2')";

			if(mysqli_query($link,$insert5)){
				echo "Empleado insertado en la tabla";
			}else{
				echo "ERROR: Imposible insertar";
			}


			echo "<br>";
			echo "<br>";


			$insert6 = "INSERT INTO Empleados VALUES('3', '65982347C', 'Laura', 'Rodriguez', '23', '3')";

			if(mysqli_query($link,$insert6)){
				echo "Empleado insertado en la tabla";
			}else{
				echo "ERROR: Imposible insertar";
			}
			
			mysqli_close($link);

		}else{
			echo "<h1>No se ha podido conectar en la base de datos.</h1>";
		}


	?>



</body>
</html>