<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Cargar Productos</title>
</head>
<body>

		<?php
		
		$Files = $_POST['fichero'];

		$fichero1 = $Files;
		
		$link = mysqli_connect("localhost", "root", "root");

		if($link){

			mysqli_select_db($link, 'PedroPerezEmpresa');

			$fichero = file($fichero1);

			for($i = 0; $i<sizeof($fichero); $i++){

				$array = explode("-", $fichero[$i]);

				$query = "SELECT * FROM Departamentos WHERE CodDep = \"$array[0]\"";

				if(mysqli_num_rows(mysqli_query($link,$query))>0){
					
					echo "ERROR: Departamento ya existente." . "<br>";

				}else{

					$insert = "INSERT INTO Departamentos VALUES(\"$array[0]\" , \"$array[1]\" , \"$array[2]\")";

					if(mysqli_query($link,$insert)){

						echo "Producto insertado en la tabla" . "<br>";

					}else{

						echo "ERROR: Imposible insertar" . "<br>";
					}

				}

			}

			mysqli_close($link);


		}else{
			die("ERROR: Imposible conectar.");
		}

	?>

	<a href="indexPedroPerez.php"><h1>Página Principal</h1></a>

</body>
</html>


