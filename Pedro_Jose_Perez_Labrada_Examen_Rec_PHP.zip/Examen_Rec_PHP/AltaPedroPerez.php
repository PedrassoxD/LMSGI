<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" lang="ES">
	<title>Creación</title>
</head>
<body>

	<h1>Datos del usuario.</h1>
		
	<form action="AltaPedroPerezInsert.php" method="POST">
		
		<p>Codigo Empleado <input type="text" name="codemp" placeholder="CodEmp"></p>
		<p>DNI <input type="text" name="dni" placeholder="Dni"></p>
		<p>Nombre <input type="text" name="nombre" placeholder="Nombre"></p>
		<p>Apellidos <input type="text" name="apellidos" placeholder="Apellidos"></p>
		<p>Edad <input type="text" name="edad" placeholder="Edad"></p>
		<p>Departamentos</p>
		<select align="center" name='departamentos'>;
		<option selected value='0'>Elige una opción</option>;
			<?php

				$link = mysqli_connect('localhost', 'root', 'root');

				if($link){

					mysqli_select_db($link, 'PedroPerezEmpresa');

					$query = "SELECT * FROM Departamentos";

					$result = mysqli_query($link, $query);

					while($extract = mysqli_fetch_array($result)){

						echo "<option value=".$extract[0].">".$extract[1]."</option>";

					}

					mysqli_close($link);

				}else{
					echo "ERROR: Imposible establecer la conexión con la base de datos.";
				}

			?>
		</select>
		<br>
		<br>
		<input type="submit" name="acceder" placeholder="Introducir">

	</form>

</body>
</html>