<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" lang="ES">
	<title>Creación</title>
</head>
<body>
	
	<?php 

		$link = mysqli_connect('localhost','root','root');

		$codemp = $_POST['codemp'];
		
		$dni = $_POST['dni'];
		
		$nombre = $_POST['nombre'];

		$apellidos = $_POST['apellidos'];

		$edad = $_POST['edad'];

		$departamentos = $_POST['departamentos'];
		

		if($link){

			mysqli_select_db($link, 'PedroPerezEmpresa');
			echo "Conectado";
			echo "<br>";
			echo "<br>";

			$query = "SELECT * FROM Empleados WHERE dni = \"$dni\"";

			if(mysqli_num_rows(mysqli_query($link,$query)) > 0){

				echo "ERROR: Usuario ya existente en la base de datos.";

			}else{

				$insert = "INSERT INTO Empleados VALUES(\"$codemp\", \"$dni\",\"$nombre\", \"$apellidos\", \"$edad\", \"$departamentos\")";

				if(mysqli_query($link,$insert)){
					
					echo "Empleado insertado en la tabla" . "<br>";

					$query2 = "SELECT * FROM Departamentos WHERE CodDep = \"$departamentos\"";

					if(mysqli_num_rows(mysqli_query($link,$query2)) > 0){

						$update = "UPDATE Departamentos SET num_emp = num_emp+1 WHERE CodDep = \"$departamentos\"";

						if(mysqli_query($link,$update)){

							echo "Departamento actualizado.";

						}else{

							echo "ERROR: Imposible actualizar.";

						}

					}else{

						echo "ERROR: No existe el departamento.";

					}

				}else{
					echo "ERROR: Imposible insertar" . $link->error;
				}

			}

			mysqli_close($link);
			
		}else{
			echo "Imposible conectar.";
	}
	
	?>

</body>
</html>